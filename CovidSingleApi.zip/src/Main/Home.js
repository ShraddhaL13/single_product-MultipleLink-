  import React from 'react'
  import './Home.css'


  export default function Home() {
    return (
      <div className="container-fluid">
        {/* <img  className ="img" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTY0JeyLTcn-kwLcHWl0gf3XzfFnot6eshV2ms8RVkEmzZst74I4X24PO8KCT7inFz46W0&usqp=CAU"
        alt='/' />       */}

        <img className='img' src="https://www.developeronrent.com/blogs/wp-content/uploads/2017/12/mean-stack-vs-mern-stack.jpg"
        alt='/' height={"20%"} width={"100%"}/>
      
      </div>
    )
  }
